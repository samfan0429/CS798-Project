# SatQuMA_v2.0.0
Modelling for different SatQKD systems

Version 2.0.0 developed and released by the Space Quantum Technologies team in the Computational Nonlinear & Quantum Optics group in the Department of Physics, University of Strathclyde. Enquires can be sent to Dr Daniel Oi (daniel.oi@strath.ac.uk).

Version 1.0.0 release: April 2021.

Version 1.1.0 release: September 2021.

Version 2.0.0 release: May 2023.
